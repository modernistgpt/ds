```pip install -r requirements.txt
python script_submit.py
```