import requests
import subprocess
import io
import os
import json
from collections import defaultdict
import matplotlib.pyplot as plt
import pandas as pd
from datetime import datetime
import collections
import xgboost as xgb
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.metrics import roc_auc_score
from tqdm import tqdm  # For progress bar


def download_file_from_github(repo_url, file_path, output_filename):
    """
    download the dataset
    :param repo_url:
    :param file_path:
    :param output_filename:
    :return:
    """
    raw_url = f"{repo_url}/raw/master/{file_path}"
    response = requests.get(raw_url)

    if response.status_code == 200:
        f = open(output_filename, 'wb')
        f.write(response.content)
        print(f"Downloaded %s successfully and saved as %s!" % (file_path, output_filename))
        command = "unzip %s" % output_filename
        # Run the terminal command
        process = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
        output, error = process.communicate()
    else:
        print("cannot download the file: ", response.status_code)


def stat_data(file_name):
    """
    statistic of fields in json file
    :param file_name:
    :return:
    """
    field_stats = collections.defaultdict(lambda: {"count": 0, "null_count": 0, "min": None, "max": None, "unique_values": set()})
    file = open(file_name, 'r')

    for line in tqdm(file):
        data = json.loads(line)
        for field, value in data.items():
            field_stats[field]["count"] += 1
            if pd.isnull(value) or value == "":
                field_stats[field]["null_count"] += 1
            elif value in [True, False]:
                field_stats[field]["unique_values"].add(str(value))
            elif isinstance(value, (int, float)):
                if field_stats[field]["min"] is None or value < field_stats[field]["min"]:
                    field_stats[field]["min"] = value
                if field_stats[field]["max"] is None or value > field_stats[field]["max"]:
                    field_stats[field]["max"] = value
            elif isinstance(value, str):
                field_stats[field]["unique_values"].add(value)

    for field, stats in field_stats.items():
        print(f"Field: {field}")
        print(f"Null count: {stats['null_count']}")
        print(f"Min: {stats['min']}")
        print(f"Max: {stats['max']}")
        print(f"Unique count: {len(stats['unique_values'])}")
        print()


def plot_histogram(column_name, file_name):
    """
    plot histogram for column `column_name` read from file_name
    :param column_name:
    :param file_name:
    :return:
    """
    column_values = []

    zero_trans_amount_cnt = 0
    counter = collections.Counter()
    file = open(file_name, "r")
    for line in file:
        data = json.loads(line)
        if not pd.isnull(data[column_name]):
            column_values.append(data[column_name])
            zero_trans_amount_cnt += 1 if abs(data[column_name]) < 1e-10 else 0
            if data[column_name] >= 500:
                counter[data["isFraud"]] += 1
    print("Number of transactions with 0 dollar: ", zero_trans_amount_cnt)
    print(counter)
    # Counter({False: 894, True: 59}) T = 1000
    plt.figure(figsize=(10, 6))
    plt.hist(column_values, bins=25, color='skyblue', edgecolor='black')
    plt.title(f'Histogram of {column_name}')
    plt.xlabel(column_name)
    plt.ylabel('Frequency')
    plt.grid(True)
    plt.show()


def detect_reversal_multiswipe_transactions(file_name: str, time_span: int):
    """
    read file name and identify reverse and multi-swipe transactions
    :param file_name:
    :param time_span: the specified seconds to consider multi-swipe transactions
    :return:
    """
    multi_swipe_transactions = []
    reversed_transactions = []

    group_transactions = collections.defaultdict(list)
    file = open(file_name, "r")
    for line in file:
        trans = json.loads(line)
        accountNumber = trans["accountNumber"]
        parsed_datetime = datetime.strptime(trans["transactionDateTime"], "%Y-%m-%dT%H:%M:%S")
        transactionAmount = trans["transactionAmount"]
        trans_type = trans["transactionType"]
        is_fraud = trans["isFraud"]
        if trans_type == "REVERSAL":
            reversed_transactions.append(trans)
        else:
            group_transactions[accountNumber].append((parsed_datetime, transactionAmount, trans_type, is_fraud))

    # find multi-swipe transactions
    for account_num, transactions in group_transactions.items():
        transactions.sort(key=lambda x: x[0])  # sort increasingly based on transaction time
        for prev, curr in zip(transactions, transactions[1: ]):
            prev_time, prev_amount, prev_type, prev_is_fraud = prev
            curr_time, curr_amount, curr_type, curr_is_fraud = curr
            assert prev_time <= curr_time
            if (curr_time - prev_time).total_seconds() <= time_span and prev_amount == curr_amount:
                # a multi-swpie transactions should have same amount of dollars and within a short time-span
                # print(curr_is_fraud)
                multi_swipe_transactions.append(curr)  # avoid re-adding to the list

    print("Total of reversed transactions: ", len(reversed_transactions),
          "Total amount: ", sum([e["transactionAmount"] for e in reversed_transactions]))
    print("Total of multi swipe transactions: ", len(multi_swipe_transactions),
          "Total amount: ", sum([e[1] for e in multi_swipe_transactions]))
    return reversed_transactions, multi_swipe_transactions


def stat_categorical_field(column_name, file_name):
    counter = collections.Counter()
    file = open(file_name, "r")
    for line in file:
        data = json.loads(line)
        counter[(data[column_name], data["isFraud"])] += 1
        # if data[column_name] == "ADDRESS_VERIFICATION": assert data["transactionAmount"] == 0.0

    label = False
    data = dict([(k, freq) for (k, v), freq in counter.items() if v == label])

    # Plotting the pie chart
    plt.figure(figsize=(8, 8))
    plt.pie(data.values(), labels=data.keys(), autopct='%1.1f%%', startangle=140)
    plt.title("Distribution of %s when label is %s" % (column_name, label))
    plt.axis('equal')  # Equal aspect ratio ensures that pie is drawn as a circle.
    plt.show()
    print(counter)


def detect_fraudulent_trans(infile):
    data = []
    file = open(infile, "r")
    for line in file:
        record = json.loads(line)
        parsed_datetime = datetime.strptime(record["transactionDateTime"], "%Y-%m-%dT%H:%M:%S")
        t = parsed_datetime.time()
        record["transactionTime"] = (t.hour * 60 + t.minute) * 60 + t.second
        data.append(record)

    df = pd.DataFrame(data)

    selected_columns = ["creditLimit", "availableMoney", "transactionAmount",
                        "merchantName", "acqCountry", "merchantCountryCode", "posEntryMode",
                        "posConditionCode", "merchantCategoryCode", "transactionType", "cardPresent"]

    categorical_features = ["merchantName", "acqCountry", "merchantCountryCode", "posEntryMode",
                            "posConditionCode", "merchantCategoryCode", "transactionType", "cardPresent"]

    X = df[selected_columns]
    y = df["isFraud"]

    # Define the column transformer to handle categorical features
    categorical_transformer = Pipeline(steps=[('onehot', OneHotEncoder(handle_unknown='ignore'))])

    preprocessor = ColumnTransformer( transformers=[('cat', categorical_transformer, categorical_features) ])

    # Define the XGBoost model
    model = xgb.XGBClassifier(n_estimators=100, max_depth=6, learning_rate=0.3)

    # Create the pipeline with the preprocessor and model
    pipeline = Pipeline(steps=[('preprocessor', preprocessor), ('model', model)])

    # Split the data into training and testing sets
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)
    pipeline.fit(X_train, y_train)  # fiting

    # metric
    y_pred_proba = pipeline.predict_proba(X_test)[:, 1]
    roc_auc = roc_auc_score(y_test, y_pred_proba)
    print("ROC AUC:", roc_auc)

    # Get feature importance
    feature_importance = model.feature_importances_
    features = X.columns

    # Print feature importance
    print("Feature Importance:")
    L = sorted([(importance, feature) for feature, importance in zip(features, feature_importance)])
    print(L[::-1])


if __name__ == '__main__':
    repo_url = "https://github.com/CapitalOneRecruiting/DS"
    file_path = output_filename = "transactions.zip"
    file_name = "transactions.txt"

    # q1
    # download_file_from_github(repo_url, file_path, output_filename)
    # q1
    # stat_data(file_name)

    # q2
    # plot_histogram("transactionAmount", file_name)

    # q3
    # detect_reversal_multiswipe_transactions(file_name, time_span=2)

    # q4
    detect_fraudulent_trans(file_name)


